import UI.Hangemann;
import UI.UIHangman;
import org.junit.jupiter.api.Test;
import java.util.*;

public class HangmanTest {
    char[] raten = new char[20];


    public static int leben = 8;
    char[] geheimesWort;


    @Test
    public void keinTest () {

        Hangemann game = new HangemannImpl() {
            @Override
            public void printWort(char[] geheimesWort) {

            }

            @Override
            public void zeichnetGalgen(int leben) throws StringIndexOutOfBoundsException {

            }
        };

        woerterliste1();
        game.zeichnetGalgen(2);
        UIHangman.printWort(geheimesWort);

    }

    @Test
    public void woerterliste1() throws StringIndexOutOfBoundsException {
        LinkedList<String> hangmanliste = new LinkedList();

        //inhalte werden hinzugefügt
        hangmanliste.add("Konstruktor");
        hangmanliste.add("Listen");
        hangmanliste.add("Schleife");
        hangmanliste.add("Array");
        hangmanliste.add("Methoden");

        geheimesWort = hangmanliste.get((int) (Math.random() * hangmanliste.size())).toCharArray();
    }

    @Test
    public void woerterliste2() throws NegativeArraySizeException {
        List<String> myArrayList = new ArrayList<>();

        //inhalte werden hinzugefügt
        myArrayList.add("Konstruktor");
        myArrayList.add("Listen");
        myArrayList.add("Schleife");
        myArrayList.add("Array");
        myArrayList.add("Methoden");

        geheimesWort= myArrayList.get((int) (Math.random() * myArrayList.size())).toCharArray();
        //System.out.println(myArrayList.get((int) (Math.random() * myArrayList.size())).toCharArray()); ;
    }

    @Test
    public void woerterliste3() throws EmptyStackException {
        List<String> myStack = new Stack<>();

        //inhalte werden hinzugefügt
        myStack.add("Konstruktor");
        myStack.add("Listen");
        myStack.add("Schleife");
        myStack.add("Array");
        myStack.add("Methoden");

        geheimesWort = myStack.get((int) (Math.random() * myStack.size())).toCharArray();
    }

    @Test
    void starteSpiel1() {
        woerterliste1();

        System.out.println("Das gegebene Wort hat " + geheimesWort.length + " Buchstaben");
        for (int i = 0; i < geheimesWort.length; i++) {
            System.out.print("_");
        }

        do {
            //prufen = false;
            System.out.println("\nErraten Sie mal ein Buchstabe");


            raten[0] = 'l';
            System.out.println(raten);
            leben--;
            for (int i = 0; i < raten.length; i++) {
                for (int j = 0; j < geheimesWort.length; j++) {
                    if (raten[i] != geheimesWort[j]) {
                        if (raten[j] != geheimesWort[j]) {
                            raten[j] = '_';
                        }
                    }
                }
            }

            } while (leben>-1);

        /*if (leben <= -1){
            System.out.println("Du bist verloren! :(");
        }
        if (ausgeben == wort){
            System.out.println("Du hast gewonnen");
        }*/

    }

    @Test
    void starteSpiel2(){
        woerterliste2();
        System.out.println("Das gegebene Wort hat " + geheimesWort.length + " Buchstaben");
        for(int i =0; i< geheimesWort.length; i++){
            System.out.print("_");
        }
    }

    @Test
    void starteSpiel3() {
        woerterliste3();
        System.out.println("Das gegebene Wort hat " + geheimesWort.length + " Buchstaben");
        for(int i =0; i< geheimesWort.length; i++){
            System.out.print("_");
        }
    }

}
