package UI;

import java.io .*;
import java.net.Socket;
import java.util.Scanner;

public class UIHangman {
    private static final String PRINT = "print";
    private static final String EXIT = "exit";
    private static final String CONNECT = "connect";
    private static final String OPEN = "open";
    private static final String SET = "set";
    private final PrintStream outStream;
    private final BufferedReader inBufferedReader;
    private final String playerName;

    public static void main(String[] args) throws IOException {
        System.out.println("\n\t\t       COMPUTERMÄNNCHEN");
        System.out.println("\nUnd so geht's:");
        System.out.println("\nSie bekommen ein beliebiges Wort gegeben, welches sie selbst \ndurch das Erraten von Buchstaben versuchen müssen zu entziffern. \nSie können es aber auch mit Wörtern versuchen. :D ");
        System.out.println("Aber aufgepasst!! Bei jeder falschen Eingabe, \nwird der unschuldige Roboter mehr zur Verdamnis gebracht! >_<");
        System.out.println("\nAlso geben Sie sich Mühe und retten sie den Roboter!!!!!");
        System.out.println("\nViel Erfolg! :)");

        System.out.println("\nGeben Sie Ihren Namen ein: ");
        Scanner scan = new Scanner(System.in);
        String name = String.valueOf(scan.next());
        System.out.println("\nWillkommen " + name);
        System.out.println("Lass uns Spielen! ");

        UIHangman userCmd = new UIHangman("TestUser", System.out, System.in);

        userCmd.printUsage();
        userCmd.runCommandLoop();
    }

    public UIHangman(String playerName, PrintStream os, InputStream is) throws IOException {
        this.playerName = playerName;
        this.outStream = os;
        this.inBufferedReader = new BufferedReader(new InputStreamReader(is));
    }

    public void printUsage() {
        StringBuilder b = new StringBuilder();

        b.append("\n");
        b.append("\n");
        b.append("valid commands:");
        b.append("\n");
        b.append(CONNECT);
        b.append(".. connect as tcp client");
        b.append("\n");
        b.append(OPEN);
        b.append(".. open port become tcp server");
        b.append("\n");
        b.append(PRINT);
        b.append(".. print board");
        b.append("\n");
        b.append(SET);
        b.append(".. set a piece");
        b.append("\n");
        b.append(EXIT);
        b.append(".. exit");

        this.outStream.println(b.toString());
    }

    public void runCommandLoop() {
        boolean again = true;

        while (again) {
            boolean rememberCommand = true;
            String cmdLineString = null;

            try {
                // read user input
                cmdLineString = inBufferedReader.readLine();

                // finish that loop if less than nothing came in
                if (cmdLineString == null) break;

                // trim whitespaces on both sides
                cmdLineString = cmdLineString.trim();

                // extract command
                int spaceIndex = cmdLineString.indexOf(' ');
                spaceIndex = spaceIndex != -1 ? spaceIndex : cmdLineString.length();

                // got command string
                String commandString = cmdLineString.substring(0, spaceIndex);

                // extract parameters string - can be empty
                String parameterString = cmdLineString.substring(spaceIndex);
                parameterString = parameterString.trim();

                // start command loop
                switch (commandString) {
                    case PRINT:
                        this.doSkeleton(PRINT);
                        break;
                    case CONNECT:
                        this.doSkeleton(CONNECT, parameterString);
                        break;
                    case OPEN:
                        this.doSkeleton(OPEN);
                        break;
                    case SET:
                        this.doSkeleton(SET, parameterString);
                        // redraw
                        break;
                    case "q": // convenience
                    case EXIT:
                        again = false;
                        System.exit(1);
                        break; // end loop

                    default:
                        this.outStream.println("unknown command:" + cmdLineString);
                        this.printUsage();
                        rememberCommand = false;
                        break;
                }
            } catch (IOException ex) {
                this.outStream.println("cannot read from input stream - fatal, give up");
                again = false;
            }
        }
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    //                                           ui method implementations                                        //
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    private void doSkeleton(String cmd) {
        this.doSkeleton(cmd, null);
    }

    private void doSkeleton(String cmd, String parameterString) {
        System.out.print("command: " + cmd);
        if(parameterString == null) {
            System.out.print("\n");
        } else {
            System.out.println("(" +  parameterString + ")");
        }
    }

    // Spieler werden ausgewählt und werden miteinander verbunden
    public UIHangman (Socket spieler1, Socket spieler2, PrintStream outStream, BufferedReader inBufferedReader, String playerName){
        this.outStream = outStream;
        this.inBufferedReader = inBufferedReader;
        this.playerName = playerName;
    }

    // führt Spiel aus
    public void guess (){

    }

    // eingegebene Wort wird versteckt
    public void seecretWord(char[] raten){

    }

    // Loses im Spiel
    public void rip (int lives) {
    }

    // protokolliert das Erraten
    public void checkForWin (char[] raten){
    }

    // wechselt Position der Spieler
    public void switchPlayers (Socket spieler1, Socket spieler2) {

    }

    /**
     *
     * @param geheimesWort
     * @return
     * @throws ArrayIndexOutOfBoundsException
     */
    public static void printWort(char[] geheimesWort) throws ArrayIndexOutOfBoundsException {
        for(int  i = 0; i < geheimesWort.length; i++){
            System.out.print(geheimesWort[i]);
        }

    }

    /** zeichnet den Galgen
     * @param leben Leben der Spieler
     * @return liefert den sterbenden Galgen zurück
     * @throws StringIndexOutOfBoundsException
     */
    void zeichnetGalgen(int leben) throws StringIndexOutOfBoundsException {

    }

    /**
     * Stand der Leben
     * @param leben Leben der Spieler
     * @return gibt das aktuelle Stand der Leben zurück
     */
    void updateLeben(int leben){

    }

    /**
     * pruefen, ob Spieler richtig oder falsch errattet haben nach jeder Eingabe
     * @param eingabewort Buchstaben die eingegeben sind
     * @param wort das aktuelle Wort
     * @return gibt an, ob es richtig oder falsch erraten wurde
     */
    void check (char [] eingabewort, char [] wort){

    }

    /**
     * prueft am Ende ob man gewonnen oder gewonnen hat
     * @param leben aktuelle Leben des Spielers
     * @param ausgeben gibt den Buchstaben/ das Wort wieder
     * @param wort aktuelles Wort
     */
    void pruefen (int leben, char[] ausgeben, char[] wort){

    }
}