package UI;
import java.util.EmptyStackException;

// @author Gizem
//@author Linh
//@author waindja

public interface Hangemann {

    /**
     * Kanal zwischen Spieler und den Servern
     */
    int DEFAULT_PORT = 6907;

    /**
     * eine Sammlung von Wörtern
     *
     * @throws EmptyStackException
     * @throws NegativeArraySizeException
     */
    void woerterListe() throws EmptyStackException, NegativeArraySizeException;

    /**
     * fuehrt Spiel aus
     */
    void starteSpiel();

    void printWort(char[] geheimesWort);

    void zeichnetGalgen(int leben) throws StringIndexOutOfBoundsException;
}
