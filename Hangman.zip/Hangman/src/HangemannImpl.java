import UI.Hangemann;

public abstract class HangemannImpl implements Hangemann {

    @Override
    public void woerterListe() {

    }

    @Override
    public void starteSpiel() {

    }

}
